(function() {
    "use strict"

    const Setting = {
        dataSeperator : "/",
        nodeJS : true
    }
    
    module.exports = Setting
})()