(function() {
    "use strict"

    const Setting = {
        dataSeperator : "/",
        nodeJS : true,
        version : "0.1.1",
        itemStack : 20,
        invenLimit : 10
    }
    
    module.exports = Setting
})()