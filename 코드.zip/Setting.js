(function() {
    "use strict"

    const Setting = {
        dataSeperator : "/",
        nodeJS : true,
        version : "0.5.0",
        itemStack : 20,
        invenLimit : 20
    }
    
    module.exports = Setting
})()