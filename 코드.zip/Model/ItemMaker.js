(function() {
    "use strict"
    const ItemRepository = require("../Repository/ItemRepository")
    const NameDto = require("../Dto/NameDto")

    const ItemMaker = function(name, number, nick, meta) {
        this.name = name
        this.number = number

        let nameDto = new NameDto(name)
        let basicItemDto = ItemRepository.getBasicInfo(nameDto)
        this.type = basicItemDto.type
        this.stack = basicItemDto.stack

        if(basicItemDto.type === "hold") {
            this.meta = Object.assign({inven : []}, meta)
        } else if(basicItemDto.type === "tool") {
            let toolItemDto = ItemRepository.getToolInfo(nameDto)
            this.meta = Object.assign(toolItemDto, meta)
        } else {
            this.meta = meta
        }

        if(this.meta) {
            this.nick = nick
        }
    }

    module.exports = ItemMaker
})()