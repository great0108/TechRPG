(function() {
    "use strict"

    const HashDto = function(hash) {
        this.hash = hash
    }
    
    module.exports = HashDto
})()