(function() {
    "use strict"

    const BasicItemDto = function(type, stack) {
        this.type = type
        this.stack = stack
    }
    
    module.exports = BasicItemDto
})()