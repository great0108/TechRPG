(function() {
    "use strict"

    const BasicItemDto = function(type, stack, heat) {
        this.type = type
        this.stack = stack
        this.heat = heat
    }
    
    module.exports = BasicItemDto
})()