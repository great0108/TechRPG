(function() {
    "use strict"

    const CraftItemDto = function(items, tools) {
        this.items = items
        this.tools = tools
    }
    
    module.exports = CraftItemDto
})()