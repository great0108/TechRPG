(function() {
    "use strict"

    const WritingDto = function(text) {
        this.text = text
    }
    
    module.exports = WritingDto
})()