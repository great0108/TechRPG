(function() {
    "use strict"

    const NameTierDto = function(name, tier) {
        this.name = name
        this.tier = tier
    }

    module.exports = NameTierDto
})()