(function() {
    "use strict"

    const CraftNumDto = function(craftNum) {
        this.craftNum = craftNum
    }
    
    module.exports = CraftNumDto
})()