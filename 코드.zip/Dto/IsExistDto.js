(function() {
    "use strict"

    const IsExistDto = function(isExist) {
        this.isExist = isExist
    }
    
    module.exports = IsExistDto
})()