(function() {
    "use strict"

    const InvenDto = function(inven) {
        this.inven = inven
    }
    
    module.exports = InvenDto
})()