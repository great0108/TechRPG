(function() {
    "use strict"

    const MakeUserDto = function(hash, user) {
        this.hash = hash
        this.user = user
    }
    
    module.exports = MakeUserDto
})()