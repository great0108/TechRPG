(function() {
    "use strict"

    const NameDto = function(name) {
        this.name = name
    }
    
    module.exports = NameDto
})()