(function() {
    "use strict"

    const MapDto = function(map, location) {
        this.map = map
        this.location = location
    }
    
    module.exports = MapDto
})()