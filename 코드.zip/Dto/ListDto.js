(function() {
    "use strict"

    const ListDto = function(list) {
        this.list = list
    }
    
    module.exports = ListDto
})()