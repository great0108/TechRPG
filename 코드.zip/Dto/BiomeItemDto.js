(function() {
    "use strict"

    const BiomeItemDto = function(items) {
        this.items = items
    }
    
    module.exports = BiomeItemDto
})()