(function() {
    "use strict"

    const MakeWritingDto = function(title, text) {
        this.title = title
        this.text = text
    }
    
    module.exports = MakeWritingDto
})()