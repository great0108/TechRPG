(function() {
    "use strict"

    const MessageDto = function(message) {
        this.message = message
    }
    
    module.exports = MessageDto
})()