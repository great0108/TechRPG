(function() {
    "use strict"

    const CraftNameDto = function(name, craftNum) {
        this.name = name
        this.craftNum = craftNum
    }
    
    module.exports = CraftNameDto
})()